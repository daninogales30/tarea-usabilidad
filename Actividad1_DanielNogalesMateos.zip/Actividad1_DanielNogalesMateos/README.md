## Daniel Nogales Mateos
### ej1.html
1. He añadido listas para organizar mejor la información.
2. He usado \<aside> en lugar de \<div\> para el contenido adicional.
3. Mejoré la jerarquía de encabezados usando \<h3\> en vez de \<h4\>.
4. He ajustado el tamaño de la fuente para mejorar la legibilidad.
5. He cambiado el texto del enlace a uno más facil de interpretar.

- Antes:
![antes](ej1/antes.png)
- Despues:
![antes](ej1/despues.png)

### ej1.css
1. He cambiado el color del texto y también he aumentado su tamaño para una mejor lectura.
2. He cambiado la fuente de 'Times New Roman' a 'Arial'.
3. He aumentado el ancho máximo a 800px.
4. He quitado las mayúsculas en los títulos mas pequeños.
5. He mejorado los estilos de enlaces y el contraste en la caja de contenido.

  
### ej2.html
1. He cambiado la fuente a Arial y también he aumentado el tamaño del texto a 14px para que sea mas legible.
2. He ajustado el ancho del formulario (máximo de 600px) y le he colocado un fondo claro.
3. Le he añadido placeholder en los campos de entrada y los hice más intuitivos.
4. Tmabién, añadí validación con required para campos obligatorios y usé tipos de entrada más específicos (email, tel).
5. He mejorado la apariencia del botón con un efecto de hover.

- Antes:
![antes](ej2/antes.png)
- Despues:
![antes](ej2/despues.png)

### ej3.html
1. He cambiado el ancho de la imagen de 300px a 100% para que se ajuste al contenedor y sea responsiva.
2. He añadido una descripción a la etiqueta alt para, que en caso de que no se cargue la imagen, haya una descripcion sobre ella. 
3. He agregado un fondo algo transparente detrás del texto para mejorar la legibilidad.
4. He cambiado el color del texto a blanco para aumentar el contraste con el fondo.

- Antes:
![antes](ej3/antes.png)
- Despues:
![antes](ej3/despues.png)

### ej4.html
1. He vuelto a elegir Arial porque lo veo una fuente muy agradable a la vista y he mantenido un contraste entre el texto negro y el fondo blanco.
2. Aumenté el margen y el padding entre los elementos para evitar que se vean amontonados.
3. La barra de navegación es más visible con un fondo azul y le he puesto un efecto hover en los enlaces que coloca otro color al pasar por encima, lo que significa que mejora la visibilidad y funcionalidad.
4. He ajustado los bordes y el padding en las celdas para facilitar la lectura de los datos.

- Antes:
![antes](ej4/antes.png)
- Despues:
![antes](ej4/despues.png)

